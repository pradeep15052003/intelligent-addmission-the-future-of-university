# Intelligent-Admissions-The-Future-of-University-Decision-Making-with-ML

video demonstration - https://drive.google.com/file/d/1xhdmteNk06-WAMhFX70zZVgn7yu9GXoN/view?usp=share_link
